<div class="flex flex-col bg-[#24252d] min-h-screen">
  <div class="flex flex-row justify-between p-4 text-xl text-white">
    <div class="flex flex-row gap-4">
      <div class="ml-8">NFT</div>
      <input
        class="bg-[#1a1a20] rounded-2xl placeholder:pl-2 placeholder:text-sm placeholder:items-center"
        type="text"
        placeholder="Search..."
      />
    </div>

    <div class="flex flex-row gap-20">
      <a href="/">Explore</a>
      <a href="/">My Items</a>
      <a href="/">Sell</a>
    </div>

    <div>
      <button
        class="bg-gradient-to-r from-pink-500 to-rose-500 rounded-xl px-4 py-1 hover:from-pink-700"
        >Create</button
      >
      <button class="px-4 py-1">Connect</button>
    </div>
  </div>
  <div class="flex mt-10 items-center justify-center my-4">
    <div
      class="w-[70%] bg-gradient-to-r from-pink-500 to-rose-500 flex flex-row rounded-xl items-center justify-between p-8"
    >
      <p class="text-3xl text-bold text-white">
        Discover, collect and sell Extraordianry NFTs
      </p>
      <img
        src="assets/coin.png"
        class="w-32 h-32 animate-bounce transition duration-1000"
        alt=""
      />
    </div>
  </div>
  <div class="flex justify-center items-center flex flex-col">
    <p class="text-white text-3xl my-4">Top Sellers</p>
    <div class="flex flex-row gap-5 rounded-xl">
      <div
        class="bg-[#2a2d3a] w-48 h-48 rounded-2xl flex justify-center items-center flex-col"
      >
        <img src="assets/seller1.jpg" class="rounded-full" alt="" />
        <p class="text-white text-lg mt-2">James Bond</p>
        <p class="text-white text-lg">10 ETH</p>
      </div>
      <div
        class="bg-[#2a2d3a] w-48 h-48 rounded-2xl flex justify-center items-center flex-col"
      >
        <img src="assets/seller2.png" class="rounded-full" alt="" />
        <p class="text-white text-lg mt-2">Jet Lee</p>
        <p class="text-white text-lg">10 ETH</p>
      </div>
      <div
        class="bg-[#2a2d3a] w-48 h-48 rounded-2xl flex justify-center items-center flex-col"
      >
        <img src="assets/seller3.png" class="rounded-full" alt="" />
        <p class="text-white text-lg mt-2">Cow Xi</p>
        <p class="text-white text-lg">10 ETH</p>
      </div>
      <div
        class="bg-[#2a2d3a] w-48 h-48 rounded-2xl flex justify-center items-center flex-col"
      >
        <img src="assets/seller4.png" class="rounded-full" alt="" />
        <p class="text-white text-lg mt-2">Man Dem</p>
        <p class="text-white text-lg">10 ETH</p>
      </div>
      <div
        class="bg-[#2a2d3a] w-48 h-48 rounded-2xl flex justify-center items-center flex-col"
      >
        <img src="assets/seller5.png" class="rounded-full" alt="" />
        <p class="text-white text-lg mt-2">Goode Bye</p>
        <p class="text-white text-lg">10 ETH</p>
      </div>
    </div>
    <div class="flex justify-center items-center flex flex-col">
      <p class="text-white text-3xl my-8">Hot Bids</p>
      <div class="grid grid-cols-4 grid-rows-2 gap-4 uppercase gap-y-8">
        <div
          class="bg-[#2a2d3a] rounded-2xl flex justify-center items-center flex-col overflow-hidden"
        >
          <img src="assets/bids1.png" class="w-64 h-64 rounded-2xl" alt="" />
          <p class="text-white text-lg mt-2">abstact smoke red</p>
          <div class="flex flex-row justify-around">
            <div class="text-white test-lg">1.33 ETH</div>
          </div>
        </div>
        <div
          class="bg-[#2a2d3a] rounded-2xl flex justify-center items-center flex-col overflow-hidden"
        >
          <img src="assets/bids2.png" class="w-64 h-64 rounded-2xl" alt="" />
          <p class="text-white text-lg mt-2">rps</p>
          <div class="flex flex-row justify-around">
            <div class="text-white test-lg">6.88 ETH</div>
          </div>
        </div>
        <div
          class="bg-[#2a2d3a] rounded-2xl flex justify-center items-center flex-col overflow-hidden"
        >
          <img src="assets/bids3.png" class="w-64 h-64 rounded-2xl" alt="" />
          <p class="text-white text-lg mt-2">rahul vivek</p>
          <div class="flex flex-row justify-around">
            <div class="text-white test-lg">4.90 ETH</div>
          </div>
        </div>
        <div
          class="bg-[#2a2d3a] rounded-2xl flex justify-center items-center flex-col overflow-hidden"
        >
          <img src="assets/bids4.png" class="w-64 h-64 rounded-2xl" alt="" />
          <p class="text-white text-lg mt-2">kohli gambhir</p>
          <div class="flex flex-row justify-around">
            <div class="text-white test-lg">8.99 ETH</div>
          </div>
        </div>
        <div
          class="bg-[#2a2d3a] rounded-2xl flex justify-center items-center flex-col overflow-hidden"
        >
          <img src="assets/bids5.png" class="w-64 h-64 rounded-2xl" alt="" />
          <p class="text-white text-lg mt-2">cristiano messi</p>
          <div class="flex flex-row justify-around">
            <div class="text-white test-lg">10 ETH</div>
          </div>
        </div>
        <div
          class="bg-[#2a2d3a] rounded-2xl flex justify-center items-center flex-col overflow-hidden"
        >
          <img src="assets/bids6.png" class="w-64 h-64 rounded-2xl" alt="" />
          <p class="text-white text-lg mt-2">Lebron curry</p>
          <div class="flex flex-row justify-around">
            <div class="text-white test-lg">4.7 ETH</div>
          </div>
        </div>
        <div
          class="bg-[#2a2d3a] rounded-2xl flex justify-center items-center flex-col overflow-hidden"
        >
          <img src="assets/bids7.png" class="w-64 h-64 rounded-2xl" alt="" />
          <p class="text-white text-lg mt-2">abstact</p>
          <div class="flex flex-row justify-around">
            <div class="text-white test-lg">5.99 ETH</div>
          </div>
        </div>
        <div
          class="bg-[#2a2d3a] rounded-2xl flex justify-center items-center flex-col overflow-hidden"
        >
          <img src="assets/bids8.png" class="w-64 h-64 rounded-2xl" alt="" />
          <p class="text-white text-lg mt-2">smoke greens</p>
          <div class="flex flex-row justify-around">
            <div class="text-white test-lg">1.33 ETH</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
